﻿using SplashKitSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4._2
{
    public class MyLine : Shape
    {
            float _startX;
            float _startY;
            float _endX;
            float _endY;
            float _length = new Random().Next(30,50);
            public float StartX
            {
                get { return _startX; }
                set { _startX = value; }
            }
            public float StartY
            {
                get { return _startY; }
                set { _startY = value; }
            }
            public float EndX
            {
                get { return _endX; } set { _endX = value; }
            }
            public float EndY
            {
                get { return _endY; }
                set { _endY = value; }
            }
            public MyLine(Color clr,float startX, float startY, float endX, float endY) : base(clr)
            {
            
            }

            public MyLine() : this(Color.Orange,0,0,20,20) { }

            public override void Draw()
            {
                SplashKit.DrawLine(Color,X,Y-_length,X,Y+_length);
                if (Selected == true)
                {
                    DrawOutline();
                }
            }

            public override void DrawOutline()
            {
                SplashKit.DrawCircle(Color.Black, X, Y-_length, 3);
                SplashKit.DrawCircle(Color.Black, X, Y+_length, 3);
            }

            public override bool IsAt(Point2D coor)
            {
                if(coor.X >= X-5 && coor.X <= X+5 && coor.Y >= Y-_length && coor.Y <= Y+_length) 
                { return true; } else { return false;}
            }
        public override void SaveTo(StreamWriter writer)
        {
            writer.WriteLine("Line");
            base.SaveTo(writer);
            writer.WriteLine(StartX);
            writer.WriteLine(StartY);
            writer.WriteLine(EndX);
            writer.WriteLine(EndY);
        }
        public override void LoadFrom(StreamReader reader)
        {
            base.LoadFrom(reader);
            StartX = reader.ReadSingle();
            StartY = reader.ReadSingle();
            EndX = reader.ReadSingle();
            EndY = reader.ReadSingle();
        }
    }
}