﻿using SplashKitSDK;
using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4._2
{
    public class MyCircle : Shape
    {
        int _radius;
        public int Radius
        {
            get { return _radius; }
            set { _radius = value; }
        }
        public MyCircle (Color clr,int radius) :base(clr)
        {
            _radius = radius;
        }
        public MyCircle() :this(Color.Blue,50) { }
        public override void Draw()
        {
            SplashKit.FillCircle(Color,X,Y,_radius);
            if (Selected == true)
            {
                DrawOutline();
            }

        }
        public override void DrawOutline()
        {
            SplashKit.DrawCircle(Color.Black,X ,Y ,(_radius + 2));
        }
        public override bool IsAt(Point2D coor)
        {
            Point2D location = new()
            { X = X, Y = Y };
            Circle _circle = SplashKit.CircleAt(location, _radius);
            return SplashKit.PointInCircle(coor, _circle);
        }
        public override void SaveTo(StreamWriter writer)
        {
            writer.WriteLine("Circle");
            base.SaveTo(writer);
            writer.WriteLine(Radius);
        }
        public override void LoadFrom(StreamReader reader)
        {
            base.LoadFrom(reader);
            Radius = reader.ReadInteger();
        }
    }
}