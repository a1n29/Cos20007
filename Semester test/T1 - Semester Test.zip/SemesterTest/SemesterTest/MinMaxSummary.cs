﻿

namespace SemesterTest
{
    public class MinMaxSummary:SummaryStrategy
    {
        public override void PrintSummary(List<int> numbers)
        {
            Console.WriteLine("Your minimum number is: " + Minimum(numbers) + "\nYour maximum number is: " + Maximum(numbers));
        }
        private int Minimum(List<int> numbers)
        {
            return numbers.Min();
        }
        private int Maximum(List<int> numbers)
        {
            return numbers.Max();
        }
    }
}
