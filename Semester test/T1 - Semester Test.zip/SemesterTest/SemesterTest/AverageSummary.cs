﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;

namespace SemesterTest
{
    public class AverageSummary:SummaryStrategy
    {
        public override void PrintSummary(List<int> numbers)
        {
            Console.WriteLine("Your average number is: " + Average(numbers));
        }
        private float Average(List<int> numbers)
        {
            int total = 0;
            for (int i = 0; i < numbers.Count; i++)
            {
                total += numbers[i];
            }
            float avg = (float)total / numbers.Count;
            return avg;
        }
    }
}
