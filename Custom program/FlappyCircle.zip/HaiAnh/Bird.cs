﻿// Import the SplashKitSDK library
using SplashKitSDK;

// Define the namespace 'HaiAnh' to encapsulate the 'Bird' class and avoid naming conflicts
namespace HaiAnh
{
    // Define the 'Bird' class, representing the player's bird object in the game
    public class Bird : GameObject
    {
        // Private fields to store the bird's x and y coordinates, velocity, gravity, and color
        private double _x, _y;
        private double _velocity;
        private double _gravity;
        private Color _mycolor;

        // Constructor to initialize a new 'Bird' object with given x and y coordinates
        public Bird(double x, double y)
        {
            _x = x;
            _y = y;
            _velocity = 0; // Bird's initial vertical velocity is zero
            _gravity = 0.5; // Gravity value to simulate falling effect
            _mycolor = Color.Red; // Bird's initial color is red
        }

        // Method to make the bird flap (move upwards) by adjusting its velocity
        public void Flap()
        {
            _velocity = -8; // Negative value to move the bird upwards when flapped
        }

        // Override the 'Update' method inherited from the 'GameObject' class
        public override void Update()
        {
            // Update the bird's velocity by adding gravity
            _velocity += _gravity;

            // Update the bird's y-coordinate based on its velocity
            _y += _velocity;
        }

        // Override the 'Draw' method inherited from the 'GameObject' class
        public override void Draw()
        {
            // Draw the bird as a filled circle with the specified color
            SplashKit.FillCircle(Mycolor, XPosition, YPosition, 20);
        }

        // Method to change the bird's color to a random color
        public void Changecolor()
        {
            _mycolor = Color.Random();
        }

        // Override the 'XPosition' property inherited from the 'GameObject' class
        public override double XPosition
        {
            get { return _x; } // Get the x-coordinate of the bird
            set { _x = value; } // Set the x-coordinate of the bird
        }

        // Override the 'YPosition' property inherited from the 'GameObject' class
        public override double YPosition
        {
            get { return _y; } // Get the y-coordinate of the bird
            set { _y = value; } // Set the y-coordinate of the bird
        }

        // Public property to get or set the bird's color
        public Color Mycolor
        {
            get { return _mycolor; } // Get the bird's color
            set { _mycolor = value; } // Set the bird's color
        }
    }
}
