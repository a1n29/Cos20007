﻿// Import the SplashKitSDK library
using SplashKitSDK;

// Define the namespace 'HaiAnh' to encapsulate the 'HighScore' class and avoid naming conflicts
namespace HaiAnh
{
    // Define the 'HighScore' class to manage the game's high score
    public class HighScore
    {
        // Private field to store the high score value
        private int _highScore;

        // Constructor to initialize a new 'HighScore' object with an initial high score of 0
        public HighScore()
        {
            _highScore = 0;
        }

        // Method to get the current high score value
        public int GetHighScore()
        {
            return _highScore;
        }

        // Method to update the high score if the provided 'score' is greater than the current high score
        public void UpdateHighScore(int score)
        {
            if (score > _highScore)
            {
                _highScore = score;
            }
        }

        // Method to reset the high score to 0
        public void ResetHighScore()
        {
            _highScore = 0;
        }

        // Public property to get or set the high score value
        public int Highscore
        {
            get { return _highScore; } // Get the current high score
            set { _highScore = value; } // Set the high score to a new value
        }
    }
}
