﻿// Import the SplashKitSDK library
using SplashKitSDK;

// Define the namespace 'HaiAnh' to encapsulate the 'GameObject' class and avoid naming conflicts
namespace HaiAnh
{
    // Define the 'GameObject' abstract class to serve as a base class for game objects
    public abstract class GameObject
    {
        // Abstract property to get or set the x-coordinate of the game object
        public abstract double XPosition { get; set; }

        // Abstract property to get or set the y-coordinate of the game object
        public abstract double YPosition { get; set; }

        // Abstract method to update the game object's state (position, velocity, etc.) in each frame
        public abstract void Update();

        // Abstract method to draw the game object on the screen
        public abstract void Draw();
    }
}
