﻿// Import the SplashKitSDK library
using SplashKitSDK;

// Define the namespace 'HaiAnh' to encapsulate the 'Pipe' class and avoid naming conflicts
namespace HaiAnh
{
    // Define the 'Pipe' class, which inherits from the 'GameObject' class
    public class Pipe : GameObject
    {
        // Private fields to store the pipe's x and y coordinates, and a bool to track if it has been passed
        private double _x, _y;
        private bool _passed;

        // Constructor to initialize a new 'Pipe' object with given x and y coordinates
        public Pipe(double x, double y)
        {
            // Set the initial position and passed status
            _x = x;
            _y = y;
            _passed = false;
        }

        // Override the 'Update' method inherited from the 'GameObject' class
        public override void Update()
        {
            // Update the pipe's position by moving it to the left by 10 units in each frame
            _x -= 10;
        }

        // Override the 'Draw' method inherited from the 'GameObject' class
        public override void Draw()
        {
            // Draw the pipe as a green rectangle using the SplashKit library,
            // with the position (_x, _y) and dimensions (50 width, 400 height)
            SplashKit.FillRectangle(Color.Green, _x, _y, 50, 400);
        }

        // Override the 'XPosition' property inherited from the 'GameObject' class
        public override double XPosition
        {
            get { return _x; } // Get the x-coordinate of the pipe
            set { _x = value; } // Set the x-coordinate of the pipe
        }

        // Override the 'YPosition' property inherited from the 'GameObject' class
        public override double YPosition
        {
            get { return _y; } // Get the y-coordinate of the pipe
            set { _y = value; } // Set the y-coordinate of the pipe
        }

        // Public property to get or set the 'Passed' status of the pipe
        public bool Passed
        {
            get { return _passed; } // Get whether the pipe has been passed
            set { _passed = value; } // Set whether the pipe has been passed
        }
    }
}