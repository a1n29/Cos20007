// Import the SplashKitSDK library
using SplashKitSDK;

// Define the namespace 'HaiAnh' to encapsulate the 'Program' class and avoid naming conflicts
namespace HaiAnh
{
    // Define the 'Program' class, which serves as the entry point for the application
    class Program
    {
        // The 'Main' method is the entry point of the application
        static void Main(string[] args)
        {
            // Create an instance of the 'Game' class to start the game
            Game game = new Game();

            // Call the 'RunGame' method of the 'Game' class to run the game loop
            game.RunGame();
        }
    }
}
