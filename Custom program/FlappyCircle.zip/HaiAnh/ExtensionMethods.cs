﻿// Import the SplashKitSDK library
using SplashKitSDK;

// Define the namespace 'HaiAnh' to encapsulate the 'ExtensionMethods' class and avoid naming conflicts
namespace HaiAnh
{
    // Define the 'ExtensionMethods' static class to hold extension methods for various data types
    public static class ExtensionMethods
    {
        // Extension method to check if a value is between two other values
        // The 'this' keyword before the first parameter of the method indicates that this is an extension method
        // It allows the method to be called on instances of the data type that the method extends
        // In this case, the extension method applies to instances of the 'double' data type
        // The 'value' parameter is the value to check, and 'lower' and 'upper' are the bounds to check against
        public static bool IsBetween(this double value, double lower, double upper)
        {
            // The method returns 'true' if 'value' is greater than or equal to 'lower' and less than or equal to 'upper'
            // Otherwise, it returns 'false'
            return value >= lower && value <= upper;
        }
    }
}
