﻿// Import the SplashKitSDK library
using SplashKitSDK;

// Define the namespace 'HaiAnh' to encapsulate the 'Medal' class and avoid naming conflicts
namespace HaiAnh
{
    // Define the 'Medal' class, representing a medal object in the game
    public class Medal : GameObject
    {
        // Private fields to store the medal's x and y coordinates, medal color, ribbon color, and medal name
        private double _x, _y;
        private Color _medalColor;
        private Color _ribbonColor;
        private string _medalName;

        // Constructor to initialize a new 'Medal' object with given x, y coordinates, medal color, ribbon color, and medal name
        public Medal(double x, double y, Color medalColor, Color ribbonColor, string medalname)
        {
            _x = x;
            _y = y;
            _medalColor = medalColor;
            _ribbonColor = ribbonColor;
            _medalName = medalname;
        }

        // Override the 'Update' method inherited from the 'GameObject' class
        public override void Update()
        {
            // The 'Update' method of the medal is empty, as medals don't have any dynamic behavior in this game
        }

        // Override the 'Draw' method inherited from the 'GameObject' class
        public override void Draw()
        {
            // Draw the medal body as a filled circle with a black outline
            SplashKit.FillCircle(_medalColor, _x, _y, 50);
            SplashKit.DrawCircle(Color.Black, _x, _y, 50);

            // Draw the ribbon as a filled rectangle with a black outline and display the medal name in the ribbon
            SplashKit.FillRectangle(_ribbonColor, _x - 20, _y + 25, 40, 20);
            SplashKit.DrawRectangle(Color.Black, _x - 20, _y + 25, 40, 20);
            SplashKit.DrawText(_medalName, Color.Black, _x - 10, _y + 30);
        }
       
        // Method to draw the appropriate medal based on the player's score
        public void DrawMedal(int score)
        {
            // Based on the player's score, display different messages and draw corresponding medals
            if (score < 20)
            {
                SplashKit.DrawText("Congratulation !!! You have earned a bronze medal, Press R to Restart", Color.Red, SplashKit.ScreenWidth() / 2 - 250, SplashKit.ScreenHeight() / 2);
                Medal _bronzemedal = new Medal(SplashKit.ScreenWidth() / 2, SplashKit.ScreenHeight() / 2 - 100, Color.RGBColor(205, 127, 50), Color.LightGreen, "#3");
                _bronzemedal.Draw();
            }
            if (score >= 20 && score < 40)
            {
                SplashKit.DrawText("Congratulation !!! You have earned a silver medal, Press R to Restart", Color.Red, SplashKit.ScreenWidth() / 2 - 250, SplashKit.ScreenHeight() / 2);
                Medal _silvermedal = new Medal(SplashKit.ScreenWidth() / 2, SplashKit.ScreenHeight() / 2 - 100, Color.Silver, Color.LightGreen, "#2");
                _silvermedal.Draw();
            }
            if (score >= 40)
            {
                SplashKit.DrawText("Congratulation !!! You have earned a gold medal, Press R to Restart", Color.Red, SplashKit.ScreenWidth() / 2 - 250, SplashKit.ScreenHeight() / 2);
                Medal _goldmedal = new Medal(SplashKit.ScreenWidth() / 2, SplashKit.ScreenHeight() / 2 - 100, Color.Gold, Color.LightGreen, "#1");
                _goldmedal.Draw();
            }
        }

        // Override the 'XPosition' property inherited from the 'GameObject' class
        public override double XPosition
        {
            get { return _x; } // Get the x-coordinate of the medal
            set { _x = value; } // Set the x-coordinate of the medal
        }

        // Override the 'YPosition' property inherited from the 'GameObject' class
        public override double YPosition
        {
            get { return _y; } // Get the y-coordinate of the medal
            set { _y = value; } // Set the y-coordinate of the medal
        }
    }
}
