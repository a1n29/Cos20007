﻿// Import the SplashKitSDK library
using SplashKitSDK;

// Define the namespace 'HaiAnh' to encapsulate the 'Game' class and avoid naming conflicts
namespace HaiAnh
{
    // Define the 'Game' class, responsible for managing the game logic and display
    public class Game
    {
        // Private fields to hold game objects and game state information
        private Bird _bird;            // The player's bird object
        private List<Pipe> _pipes;     // A list to store the pipes in the game
        private HighScore _highscore;  // Object to manage and store the high score
        private int _score;            // Current score of the player
        private bool _isGameOver;      // Bool to indicate if the game is over
        private bool _isMenu;          // Bool to indicate if the game is in the menu state
        private Color _bgcolor;        // Background color of the game
        private Medal _medal;          // Medal object to display after the game ends

        // Constructor to initialize the 'Game' object and set up the initial game state
        public Game()
        {
            // Initialize game objects and state
            _bird = new Bird(100, 400); // Create the bird object with initial position
            _pipes = new List<Pipe>(); // Initialize an empty list to store pipes
            _highscore = new HighScore(); // Initialize the high score manager
            _score = 0; // Set the initial score to zero
            _isGameOver = false; // Set the game over bool to false (game is not over)
            _bgcolor = Color.LightBlue; // Set the initial background color
            _isMenu = true; // Set the menu state bool to true (game starts in the menu state)
            _medal = new Medal(SplashKit.ScreenWidth() / 2, SplashKit.ScreenHeight() / 2 - 100, Color.RGBColor(205, 127, 50), Color.LightGreen, "#3");
            // Create a new medal object with a specific position and appearance
        }

        // Method to handle player input
        public void HandleInput()
        {
            // Check if the Space key is typed and the game is not over, then make the bird flap
            if (SplashKit.KeyTyped(KeyCode.SpaceKey) && !_isGameOver)
            {
                _bird.Flap();
            }

            // Check if the 'R' key is typed and the game is over, then restart the game
            if (SplashKit.KeyTyped(KeyCode.RKey) && _isGameOver)
            {
                ResetGame();
            }

            // Check if the 'C' key is typed, and either the game is over or not, then change the bird's color
            if (SplashKit.KeyTyped(KeyCode.CKey) && (_isGameOver || !_isGameOver))
            {
                _bird.Changecolor();
            }

            // Check if the 'B' key is typed, and either the game is over or not, then change the background color
            if (SplashKit.KeyTyped(KeyCode.BKey) && (_isGameOver || !_isGameOver))
            {
                ChangeBG();
            }

            // Check if the 'P' key is typed, and either the game is over or not, then toggle the menu state
            if (SplashKit.KeyTyped(KeyCode.PKey) && (!_isGameOver || _isGameOver))
            {
                _isMenu = !_isMenu; // Toggle the Menu state
            }
        }

        // Method to update the game state
        public void Update()
        {
            if (!_isGameOver)
            {
                // Update the bird's position and check for collisions and score
                _bird.Update();

                // Iterate through the pipes to update their positions and check for collisions and scoring
                foreach (Pipe pipe in _pipes)
                {
                    pipe.Update();

                    // Check for collision between the bird and the pipe
                    if (_bird.YPosition.IsBetween(pipe.YPosition - 15, pipe.YPosition + 415) &&
                        _bird.XPosition.IsBetween(pipe.XPosition - 15, pipe.XPosition + 65))
                    {
                        // Bird has collided with a pipe, set game over bool
                        _isGameOver = true;
                    }

                    // Check if the bird has successfully passed through the pipe
                    if (pipe.XPosition < _bird.XPosition && !pipe.Passed)
                    {
                        // Bird passed through the pipe successfully, update score
                        pipe.Passed = true;
                        _score++;
                    }
                }

                // Remove pipes that have gone off the screen to manage memory
                foreach (Pipe pipe in _pipes)
                {
                    if (pipe.XPosition < -25)
                    {
                        _pipes.Remove(pipe);
                        break; // Exit the loop to avoid issues with modifying the list while iterating
                    }
                }

                // Generate new pipes based on the score to increase difficulty
                // Gap between pipes decreases as the score increases
                if (_pipes.Count < 1 && _score < 20)
                {
                    _pipes.Add(new Pipe(new Random().Next(SplashKit.ScreenWidth(), 1000), new Random().Next(-200, -175)));
                    _pipes.Add(new Pipe(new Random().Next(SplashKit.ScreenWidth(), 1000), new Random().Next(375, 400)));
                }
                else if (_pipes.Count < 1 && _score >= 20 && _score <= 40)
                {
                    _pipes.Add(new Pipe(new Random().Next(SplashKit.ScreenWidth(), 1000), new Random().Next(-175, -150)));
                    _pipes.Add(new Pipe(new Random().Next(SplashKit.ScreenWidth(), 1000), new Random().Next(350, 375)));
                }
                else if (_pipes.Count < 1 && _score > 40)
                {
                    _pipes.Add(new Pipe(new Random().Next(SplashKit.ScreenWidth(), 1000), new Random().Next(-150, -125)));
                    _pipes.Add(new Pipe(new Random().Next(SplashKit.ScreenWidth(), 1000), new Random().Next(325, 350)));
                }

                // Check if the bird has gone off the screen (top or bottom), set game over bool
                if (_bird.YPosition >= SplashKit.ScreenHeight() || _bird.YPosition <= 0)
                {
                    _isGameOver = true;
                }
            }
        }

        // Method to draw the game objects on the screen
        public void Draw()
        {
            // Clear the screen with the current background color
            SplashKit.ClearScreen(_bgcolor);

            // Draw the bird object
            _bird.Draw();

            // Draw all the pipes in the list
            foreach (Pipe pipe in _pipes)
            {
                pipe.Draw();
            }

            // Update the high score and display it on the screen
            _highscore.UpdateHighScore(_score);
            SplashKit.DrawText("Score: " + _score / 2, Color.Orange, SplashKit.ScreenWidth() - 775, SplashKit.ScreenHeight() - 575);
            SplashKit.DrawText("HighScore: " + _highscore.GetHighScore() / 2, Color.Orange, SplashKit.ScreenWidth() - 775, SplashKit.ScreenHeight() - 565);
            SplashKit.DrawText("PRESS P TO RETURN TO GAME MENU", Color.Orange, SplashKit.ScreenWidth() - 775, SplashKit.ScreenHeight() - 555);

            // If the game is over, display a medal depending on the score achieved
            if (_isGameOver)
            {
                _medal.DrawMedal(_score);
            }

            // Refresh the screen to display the changes
            SplashKit.RefreshScreen();
        }

        // Method to run the game loop
        public void RunGame()
        {
            // Create a new window with the given title and size
            Window window = new Window("Flappy Circle", 800, 600);

            do
            {
                // If not in the menu state, handle input, update the game state, and draw the objects
                if (!_isMenu)
                {
                    HandleInput();
                    Update();
                    Draw();
                }
                else
                {
                    // If in the menu state, display the menu screen
                    ShowMenuScreen();
                }

                // Process any events and add a delay to achieve approximately 60 FPS
                SplashKit.ProcessEvents();
                SplashKit.Delay(17);
            } while (!SplashKit.QuitRequested()); // Continue the loop until the user requests to quit the game
        }

        // Method to reset the game to its initial state
        public void ResetGame()
        {
            // Reset the bird's position, clear the list of pipes, reset the score, and set game over to false
            _bird = new Bird(100, SplashKit.ScreenHeight() / 2);
            _pipes.Clear();
            _score = 0;
            _isGameOver = false;
        }
        // Method to display the menu screen and handle menu options
        private void ShowMenuScreen()
        {
            // Clear the screen and display the Menu screen
            SplashKit.ClearScreen(Color.LightBlue);
            SplashKit.LoadBitmap("logo", "logo.png");
            SplashKit.DrawBitmap("logo", SplashKit.ScreenWidth() / 2 - 115, SplashKit.ScreenHeight() / 2 - 100);
            SplashKit.DrawText("Menu", Color.Orange, SplashKit.ScreenWidth() / 2 - 400, SplashKit.ScreenHeight() / 2 - 300);
            SplashKit.DrawText("Press 'P' to Play, Press 'Space' to Jump", Color.Red, SplashKit.ScreenWidth() / 2 - 400, SplashKit.ScreenHeight() / 2 - 275);
            SplashKit.DrawText("Press 'R' to Restart", Color.Red, SplashKit.ScreenWidth() / 2 - 400, SplashKit.ScreenHeight() / 2 - 250);
            SplashKit.DrawText("Press 'C' to Change Bird's Color", Color.Red, SplashKit.ScreenWidth() / 2 - 400, SplashKit.ScreenHeight() / 2 - 225);
            SplashKit.DrawText("Press 'B' to Change Background's Color", Color.Red, SplashKit.ScreenWidth() / 2 - 400, SplashKit.ScreenHeight() / 2 - 200);
            SplashKit.DrawText("Press 'ESC' to Quit", Color.Red, SplashKit.ScreenWidth() / 2 - 400, SplashKit.ScreenHeight() / 2 - 175);
            SplashKit.RefreshScreen();

            // Wait for the player to either resume or restart
            while (_isMenu)
            {
                SplashKit.ProcessEvents();

                // Toggle the menu state if 'P' is pressed again (resume the game)
                if (SplashKit.KeyTyped(KeyCode.PKey))
                {
                    _isMenu = false;
                }
                // Restart the game if 'R' is pressed
                else if (SplashKit.KeyTyped(KeyCode.RKey))
                {
                    ResetGame();
                    _isMenu = false;
                }
                // Close the game if 'Esc' is pressed
                else if (SplashKit.KeyTyped(KeyCode.EscapeKey))
                {
                    SplashKit.CloseAllWindows();
                }
            }
        }
        // Method to change the background color
        public void ChangeBG()
        {
            _bgcolor = Color.Random();
        }
    }
}
