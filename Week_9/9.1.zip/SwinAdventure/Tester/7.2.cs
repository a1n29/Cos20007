using SwinAdventure;
using System.Collections;
namespace Tester
{
    public class Tests
    {
        Location hanoi;
        Location saigon;
        Paths path;
        [Test]
        public void PathLoc()
        {
            hanoi = new Location("Hanoi", "Hanoi");
            saigon = new Location("Saigon", "Saigon");
            path = new Paths(new string[] { "south" }, "travel", "A travel test", hanoi, saigon);
            hanoi.AddPath(path);
            Location required = saigon;
            Location output = path.Destination;
            Assert.AreEqual(required, output);
        }
        [Test]
        public void PathName()
        {
            hanoi = new Location("Hanoi", "Hanoi");
            saigon = new Location("Saigon", "Saigon");
            path = new Paths(new string[] { "south" }, "travel", "A travel test", hanoi, saigon);
            hanoi.AddPath(path);
            string required = "A travel test";
            string output = path.FullDescription;
            Assert.AreEqual(required, output);
        }
        [Test]
        public void LocPath()
        {
            hanoi = new Location("Hanoi", "Hanoi");
            saigon = new Location("Saigon", "Saigon");
            path = new Paths(new string[] { "south" }, "travel", "A travel test", hanoi, saigon);
            hanoi.AddPath(path);
            GameObject required = hanoi.Locate("south");
            GameObject output = path;
            Assert.AreEqual(required, output);
        }
    }
}