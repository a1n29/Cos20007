﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwinAdventure
{
    public class Location : GameObject, IHaveInventory
    {
        string _name;
        string _desc;
        Inventory _inventory = new Inventory();
        List<Paths> _paths;
        public Inventory Inventory { get { return _inventory; } }
        public Location(string name, string desc, List<Paths> paths) : this(name, desc)
        {
            _paths = paths;
        }
        public Location(string name, string desc) : base(new string[] {"location"}, name, desc)
        {
            _inventory = new Inventory();
            _paths = new List<Paths>();
        }
        public GameObject Locate(string id)
        {
            if (AreYou(id) == true)
            {
                return this;
            }
            foreach (Paths s in _paths)
            {
                if (s.AreYou(id))
                {
                    return s;
                }
            }
            return _inventory.Fetch(id);
        }
        public void AddPath(Paths path)
        {
            _paths.Add(path);
        }
        public override string ShortDescription
        {
            get
            {
                return $"Your location is in {Name}";
            }
        }
        public override string FullDescription
        {
            get
            {
                return $"Your location is in {Name}, Location characteristic description: {base.FullDescription} \n  {Inventory.ItemCount} items are available in this location are: {Inventory.ItemList}";
            }
        }
        public string Items
        {
            get
            {
                if (_inventory.ItemCount == 0)
                {
                    return string.Empty;
                }
                return $"There are these items in this location: {Inventory.ItemList}";
            }
        }
        public string Ways
        {
            get
            {
                string list = string.Empty;
                for (int i = 0; i <  _paths.Count; i++)
                {
                    list = list + _paths[i].FirstId + "\n";
                }
                return list;
            }
        }
    }
}
