﻿using Microsoft.Win32.SafeHandles;
using System;
namespace SwinAdventure
{
    public class Program
    {
        static void Main(string[] args)
        {
            /* <ItemGroup>
		            <PackageReference Include="Microsoft.NET.Test.Sdk" Version="17.5.0" />
		            <PackageReference Include="NUnit" Version="3.13.3" />
	           </ItemGroup>*/
            string name;
            string desc;
            Console.WriteLine("Enter your name: ");
            name = Console.ReadLine();
            Console.WriteLine("Enter you player description: ");
            desc = Console.ReadLine();
            Player player = new Player(name,desc);
            Location hanoi = new Location("Hanoi", "Capital");
            Location saigon = new Location("Saigon", "Biggest city in the south");
            Paths hanoisaigon = new Paths(new string[] { "south" }, "NorthtoSouth", "From Hanoi to Saigon", hanoi, saigon);
            hanoi.AddPath(hanoisaigon);
            Paths saigonhanoi = new Paths(new string[] { "north" }, "SouthtoNorth", "From Saigon to Hanoi", saigon, hanoi);
            saigon.AddPath(saigonhanoi);
            player.Location = hanoi;
            Item ak47 = new Item(new string[] { "ak47" }, "AK47", "High damage, moderate firerate, high accuracy");
            Item m4a4 = new Item(new string[] { "m4a4" }, "M4A4", "Moderate damage, high firerate, high accuracy");
            Item glock = new Item(new string[] { "glock" }, "Glock 18", "Low damage, low firerate, moderate accuracy");
            Item usps = new Item(new string[] { "usps" }, "USP-S", "Low damage, low firerate, moderate accuracy");
            Item karambit = new Item(new string[]{"karambit"},"Karambit","Do nothing but a fancy knife");
            Bags tbag = new Bags(new string[] { "t" }, "t side weapons", "terrorist");
            Bags ctbag = new Bags(new string[] { "ct" }, "ct side weapons", "counter terrorist");
            tbag.Inventory.Put(ak47);
            tbag.Inventory.Put(glock);
            ctbag.Inventory.Put(m4a4);
            ctbag.Inventory.Put(usps);
            hanoi.Inventory.Put(tbag);
            saigon.Inventory.Put(ctbag);
            player.Inventory.Put(karambit);
            Console.WriteLine(tbag.FullDescription);
            Console.WriteLine(ctbag.FullDescription);
            Console.WriteLine(player.FullDescription);
            Console.WriteLine(hanoi.FullDescription);
            Console.WriteLine(saigon.FullDescription);
            Console.WriteLine(hanoisaigon.FullDescription);
            Console.WriteLine(saigonhanoi.FullDescription);
        }
    }
}
