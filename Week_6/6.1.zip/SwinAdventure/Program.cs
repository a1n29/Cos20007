﻿using System;
namespace SwinAdventure
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your name: ");
            string _name = Console.ReadLine();
            Console.WriteLine("Please enter your player description: ");
            string _desc = Console.ReadLine();
            Player player = new Player(_name,_desc);
            Item apple = new Item(new string[] { "apple" }, "an apple", "This is an apple");
            Item banana = new Item(new string[] { "banana" }, "a banana", "This is a banana");
            player.Inventory.Put(apple);
            player.Inventory.Put(banana);
            Bags bag = new Bags(new string[] { "bag" }, "a bag", "This is a bag");
            player.Inventory.Put(bag);
            Item coin = new Item(new string[] { "coin" }, "a coin", "This is a coin");
            bag.Inventory.Put(coin);
            LookCommand lookcmd = new LookCommand();
            bool status = true;
            string _usercmd;
            while (status == true)
            {
                Console.WriteLine("Please enter your command: ");
                _usercmd = Console.ReadLine();
                _usercmd.ToLower();
                if ( _usercmd == "quit")
                {
                    status = false;
                    break;
                }else
                {
                    string[] _usercmd2 = _usercmd.Split(' ');
                    lookcmd.Execute(player, _usercmd2);
                }
            }
        }
    }
}
