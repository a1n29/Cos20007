﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwinAdventure
{
    public class Location : Item, IHaveInventory
    {
        Inventory _inventory = new Inventory();
        public Inventory Inventory { get { return _inventory; } }
        public Location(string[] ids, string name, string desc) : base(ids, name, desc)
        {

        }
        public GameObject Locate(string id)
        {
            if (AreYou(id) == true)
            {
                return this;
            }
            return _inventory.Fetch(id);
        }
        public override string FullDescription
        {
            get
            {
                return $"Your location is in {Name}, Location description: {FullDescription} \n Items available in this location are: {Inventory.ItemList}";
            }
        }
    }
}
