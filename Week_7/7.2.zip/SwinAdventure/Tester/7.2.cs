using SwinAdventure;
using System.Collections;

namespace Tester
{
    public class Tests
    {
        Location Location1;
        Item gem;
        Player player;
        LookCommand look;
       
        [SetUp]
        public void Setup()
        {
             Location1 = new (new string[] { "Location1" }, "a Location 1", "This is a Location 1");
             gem = new (new string[] { "gem" }, "a gem", "This is a gem");
             player = new ("HAnh","Pro gamer");
             look = new();
            player.Inventory.Put(gem); 
        }

        [Test]
        public void TestLookAtMe()
        {
            Assert.That(look.Execute(player, new string[] {"look","at","me"}),Is.EqualTo(player.FullDescription));
        }
        [Test]
        public void TestLookAtGem()
        {
            Assert.That(look.Execute(player,new string[] {"look","at","gem"}),Is.EqualTo(gem.FullDescription));
        }
        [Test]
        public void TestLookAtUnk()
        {
            player.Inventory.Take("gem");
            Assert.That(look.Execute(player, new string[] { "look", "at", "gem", "in", "inventory" }), Is.EqualTo("I cannot find the gem"));
        }
        [Test]
        public void TestLookAtGemInMe()
        {
            Assert.That(look.Execute(player, new string[] { "look", "at", "gem","in","inventory" }), Is.EqualTo(gem.FullDescription));
        }
        [Test]
        public void TestLookAtGemInLocation()
        {
            Location1.Inventory.Put(gem);
            player.Inventory.Put(Location1);
            Assert.That(look.Execute(player, new string[] { "look", "at", "gem", "in", "Location1" }), Is.EqualTo(gem.FullDescription));
        }
        [Test]
        public void TestLookAtGemInNoLocation()
        {
            Assert.That(look.Execute(player,new string[] {"look", "at", "gem", "in", "Location1" }), Is.EqualTo("I cannot find the Location1"));
        }
        [Test]
        public void TestLookAtNoGemInLocation()
        {
            player.Inventory.Put(Location1);
            Assert.That(look.Execute(player, new string[] { "look", "at", "gem", "in", "Location1" }), Is.EqualTo("I cannot find the gem"));
        }
        [Test]
        public void TestInvalidLook1()
        {
            Assert.That(look.Execute(player, new string[] { "sadboizsitinhaochinhyeuem" }),Is.EqualTo("I don't know how to look like that"));
        }
        [Test]
        public void TestInvalidLook2()
        {
            Assert.That(look.Execute(player, new string[] { "hello","at","me" }), Is.EqualTo("Error in look input"));
        }
        [Test]
        public void TestInvalidLook3()
        {
            Assert.That(look.Execute(player, new string[] { "look", "is", "gem" }), Is.EqualTo("What do you want to look at?"));
        }
        [Test]
        public void TestInvalidLook4()
        {
            Assert.That(look.Execute(player, new string[] { "look", "at", "a", "at", "b" }), Is.EqualTo("What do you want to look in?"));
        }
    }
}