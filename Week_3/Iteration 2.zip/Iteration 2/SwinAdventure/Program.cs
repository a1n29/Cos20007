using System;
using SplashKitSDK;

namespace SwinAdventure;

public class Program
{
    public void Main(string[] args)
    {
        Console.WriteLine("Hello world");
    } 
}
