﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace SwinAdventure
{
    public class Inventory
    {
        List<Item> _items = new List<Item>();
        public Inventory() 
        {
        }
        public bool HasItem(string id)
        {
            foreach (Item i in _items)
            {
                if (i.AreYou(id))
                {
                    return true;
                }
            }
            return false;
        }
        public void Put(Item item)
        {
            _items.Add(item);
        }
       
        public Item Take(string id)
        {
            Item take = Fetch(id);
                if (_items != null)
            {
                _items.Remove(take);
                return take;
            }
            return null;
        }
        public Item Fetch(string id)
        {
            foreach (Item i in _items)
            {
                if (i.AreYou(id))
                {
                    return i;
                }
            }
            return null;
        }
        public string ItemList
        {
            get
            {
                string itemlist = new ("");
                foreach (Item i in _items)
                {
                    itemlist += i.ShortDescription;
                }
                return itemlist;
            }
        }
    }
}
