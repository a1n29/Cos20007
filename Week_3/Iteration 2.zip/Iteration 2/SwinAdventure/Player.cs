﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwinAdventure
{
    public class Player : GameObject
    {
        Inventory _inventory;
        public Player(string name, string desc) : base(new string[] { "anh", "invent" }, name, desc)
        {
            _inventory = new Inventory();
        }

        public Inventory Get_inventory()
        {
            return _inventory;
        }

        public GameObject Locate(string id, Inventory _inventory)
        {
            if (AreYou(id))     
            {
                return this;
            }
            return _inventory.Fetch(id);
        }

        public override string FullDescription
        {
            get
            {
                return $"{Name}, you are carrying: \n " + _inventory.ItemList;
            }
        }

        public Inventory Inventory
        {
            get
            {
                return _inventory;
            }
        }
    }
  
}
