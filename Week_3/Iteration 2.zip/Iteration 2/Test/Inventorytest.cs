﻿using SwinAdventure;

namespace Test
{
    public class TestInventory
    {
        Item gun = new Item(new string[] { "gun" }, "a gun", "This is a gun");
        Item grenade = new Item(new string[] { "grenade" }, "a grenade", "This is a grenade");


        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void TestFindItem()
        {
            Inventory i = new Inventory();
            i.Put(gun);
            Assert.IsTrue(i.HasItem(gun.FirstId));
        }

        [Test]
        public void TestNoItemFind()
        {
            Inventory i = new Inventory();
            i.Put(gun);
            Assert.IsFalse(i.HasItem(grenade.FirstId));
        }

        [Test]
        public void TestFetchItem()
        {
            Inventory i = new Inventory();
            i.Put(gun);
            Item fetchItem = i.Fetch(gun.FirstId);

            Assert.IsTrue(fetchItem == gun);
            Assert.IsTrue(i.HasItem(gun.FirstId));
        }

        [Test]
        public void TestTakeItem()
        {
            Inventory i = new Inventory();
            i.Put(gun);
            i.Take(gun.FirstId);
            Assert.IsFalse(i.HasItem(gun.FirstId));
        }

        [Test]
        public void TestItemList()
        {
            Inventory i = new Inventory();
            i.Put(gun);
            i.Put(grenade);
            Assert.IsTrue(i.HasItem(gun.FirstId));
            Assert.IsTrue(i.HasItem(grenade.FirstId));

            string Output = "a gun (gun)a grenade (grenade)";
            Assert.That(i.ItemList,Is.EqualTo(Output));
        }

    }
}