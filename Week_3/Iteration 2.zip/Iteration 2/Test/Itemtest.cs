using SwinAdventure;
namespace Test
{
        public class TestItem
        {
            Item gun = new Item(new string[] { "gun" }, "a gun", "This is a gun");
            [SetUp]
            public void Setup()
            {

            }

            [Test]
            public void TestItemIsIdentifiable()
            {
                Assert.That(gun.AreYou("gun"), Is.True);
            }
            [Test]
            public void TestShortDescription()
            {
                Assert.That(gun.ShortDescription, Is.EqualTo("a gun (gun)"));
            }
            [Test]
            public void TestLongDescription()
            {
                Assert.That(gun.FullDescription,Is.EqualTo("This is a gun"));
            }
        }
}