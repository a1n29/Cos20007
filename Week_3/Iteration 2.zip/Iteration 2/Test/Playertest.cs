﻿using SwinAdventure;

namespace Test
{
    public class TestPlayer
    {
        Player player = new Player("Hai Anh", "Coder");
        Item gun = new Item(new string[] { "gun" }, "a gun", "This is a gun");
        Item grenade = new Item(new string[] { "grenade" }, "a grenade", "This is a grenade");
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void TestPlayerIsIdentifiable()
        {
            Assert.IsTrue(player.AreYou("anh") && player.AreYou("invent"));

        }

        [Test]
        public void TestPlayerLocatesItems()
        {
            var result = false;
            player.Inventory.Put(grenade);
            var itemsLocated = player.Locate("grenade", player.Get_inventory());
            if (grenade == itemsLocated)
            {
                result = true;
            }
            Assert.IsTrue(result);
        }

        [Test]
        public void TestPlayerLocatesItself()
        {
            var myself = player.Locate("anh", player.Get_inventory());
            var invent = player.Locate("invent", player.Get_inventory());
            var result = false;

            if (myself == player || invent == player)
            {
                result = true;
            }
            Assert.IsTrue(result);
        }

        [Test]
        public void TestPlayerLocatesNothing()
        {
            var myself = player.Locate("Hi", player.Get_inventory());
            Assert.IsNull(myself);
        }

        [Test]
        public void TestPlayerFullDescription()
        {
            player.Inventory.Put(grenade);
            player.Inventory.Put(gun);
            string Output = "Hai Anh, you are carrying: \n a grenade (grenade)a gun (gun)";
            Assert.That(player.FullDescription, Is.EqualTo(Output));
        }
    }
}