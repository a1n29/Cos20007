using SplashKitSDK;
using System.Collections.Generic;
using System.Xml.Linq;

namespace ShapeDrawer
{
    public class Drawing
    {
        private readonly List<Shape> _shapes;
        private Color _background;
        public Color Background
        {
            get
            {
                return _background;
            }
            set
            {
                _background = value;
            }
        }
        public int ShapeCount
        {
            get {return _shapes.Count;}
        }
        public Drawing (Color background)
        {
            _shapes = new List<Shape> ();
            _background = background;
        }
        public Drawing () : this(Color.White)
        {

        }
       public void Draw()
        {
            SplashKit.ClearScreen(_background);
            for (int i = 0; i < ShapeCount; i++)
            {
                _shapes[i].draw();
            }
        }
        public void AddShape(Shape shape)
        {
            _shapes.Add(shape);
        }
        public void SelectShapeAt(Point2D pt)
        {
            foreach (Shape s in _shapes)
            {
                if (s.IsAt(pt)) 
                {
                    s.Selected = true;
                }
                else
                {
                    s.Selected = false;
                }
            }
        }
        public void Removal()
        {
            
            for (int i = 0; i < _shapes.Count; i++)
            {
                if (_shapes[i].Selected)
                {
                    _shapes.Remove(_shapes[i]);
                    i--;
                }

            }
        }
        public List<Shape> SelectedShapes
        {
            get
            {
                List<Shape> result = new List<Shape>();
                foreach (Shape s in _shapes)
                {
                    if(s.Selected == true)
                    {
                        result.Add(s);
                    }
                }
                return result;
            }
        }
    }
    public class Program
    {
        public static void Main()
        {
            Drawing shapes = new Drawing (Color.Green);
            Window window = new Window("Shape Drawer", 800,
            600);
            do
            {
                SplashKit.ProcessEvents();
                SplashKit.ClearScreen();
               
                if (SplashKit.MouseClicked(MouseButton.LeftButton))
                {
                    Shape shape = new Shape( (float) SplashKit.MousePosition().X, (float) SplashKit.MousePosition().Y,100,100);
                    shapes.AddShape(shape);
                }
                if (SplashKit.MouseClicked(MouseButton.RightButton))
                {
                    shapes.SelectShapeAt(SplashKit.MousePosition());
                }   
                if (SplashKit.KeyTyped(KeyCode.SpaceKey))
                {
                    shapes.Background = Color.Random();
                }
                if (SplashKit.KeyTyped(KeyCode.BackspaceKey))
                {
                    shapes.Removal();
                }
                shapes.Draw(); 
                SplashKit.RefreshScreen();
            } while (!window.CloseRequested);
        }
    }
    public class Shape
    {
        private Color _color = Color.Random();
        private float _x;
        private float _y;
        private int _width;
        private int _height;
        private bool _selected;
        public bool Selected
        {
            get
            {
                return _selected;
            }
            set
            {
                _selected = value;
            }
        }
        public Color Color
        {
            get
            {
                return _color;
            }
            set
            {
                _color = value;
            }
        }
        public float X
        {
            get
            {
                return _x;
            }
            set
            {
                _x = value;
            }
        }
        public float Y
        {
            get
            {
                return _y;
            }
            set
            {
                _y = value;
            }
        }
        public int Width
        {
            get
            {
                return _width;
            }
            set
            {
                _width = value;
            }
        }
        public int Height
        {
            get
            {
                return _height;
            }
            set
            {
                _height = value;
            }
        }
        public Shape(float x, float y, int width, int height)
        {
            _x = x;
            _y = y;
            _width = width;
            _height = height;
        }
        public void draw()
        {
            SplashKit.FillRectangle(_color, _x, _y, _width, _height);
            if (_selected == true)
            {
                DrawOutline();
            }
        }
        public bool IsAt(Point2D coor)
        {
            return (coor.X >= _x && coor.X <= _x + _width) && (coor.Y >= _y && coor.Y <= _y + _height);
        }
        public void DrawOutline()
        {
            SplashKit.DrawRectangle(Color.Black, _x - 2, _y - 2, _width + 4, _height + 4);
        }
    }
}