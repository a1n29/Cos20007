using MainClock;

namespace Tester
{
    [TestFixture]
    internal class CounterTester
    {
        [Test]
        public void TestInit()
        {
            Counter tester = new Counter("");
            Assert.That(tester.Ticks, Is.EqualTo(0));
        }
        [Test]
        public void TestIncrease()
        {
            Counter tester = new Counter("");
            tester.Increment();
            Assert.That(tester.Ticks, Is.EqualTo(1));
        }
        [Test]
        public void TestIncreaseMore()
        {
            Counter tester = new Counter("");
            tester.Increment();
            tester.Increment();
            tester.Increment();
            Assert.That(tester.Ticks, Is.EqualTo(3));
        }
        [Test]
        public void TestReset()
        {
            Counter tester = new Counter("");
            tester.Reset();
            Assert.That(tester.Ticks, Is.EqualTo(0));
        }
    }
    
    internal class ClockTester
    {
        [Test]
        public void TestClockTick()
        {
            Clock tester = new Clock();

            for (int i = 0; i < 61; i++)
            {
                tester.Tick();
            }

                Assert.That(tester.CurrentTime, Is.EqualTo("00:01:01"));

        }
        [Test]
        public void TestClockReset()
        {
            Clock tester = new Clock();
            for (int i = 0; i < 5; i++)
            {
                tester.Tick();
            }
            tester.Reset();
            Assert.That(tester.CurrentTime, Is.EqualTo("00:00:00"));
        }
    }

}