﻿
namespace MainClock
{
    public class Counter
    {
        private int _count;
        private string _name;
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public int Ticks
        {
            get
            {
                return _count;
            }
        }
        public Counter(string name)
        {
            _name = name;
            _count = 0;
        }

        public void Increment()
        {
            _count++;
        }
        public void Reset()
        {
            _count = 0;
        }

    }
    public class Clock
    {
        Counter Secs = new Counter("Second");
        Counter Mins = new Counter("Minute");
        Counter Hours = new Counter("Hour");
        public void Tick()
        {
            Secs.Increment();
            if (Secs.Ticks == 60)
            {
                Secs.Reset();
                Mins.Increment();
            }
            if (Mins.Ticks == 60)
            {
                Mins.Reset();
                Hours.Increment();
            }
            if (Hours.Ticks == 24)
            {
                Hours.Reset();
            }
        }

        public void Reset()
        {
            Secs.Reset();
            Mins.Reset();
            Hours.Reset();
        }
        public string CurrentTime()
        {
            return $"{Hours.Ticks:00}:{Mins.Ticks:00}:{Secs.Ticks:00}";
        }
        static void Main(string[] args)
        {
            Clock clock = new Clock();
            for (int i = 0; i < 86400; i++)
            {
                Thread.Sleep(100);
                Console.Clear();
                clock.Tick();
                Console.WriteLine(clock.CurrentTime());
            }
        }
    }
}