import time
class Counter:
    def __init__(self,name):
        self._name = name
        self._count = 0

    def Increment(self):
        self._count += 1

    def Reset(self):
        self._count = 0

class Clock:
    def __init__(self):
        self.second = Counter("second(s)")
        self.minute = Counter("minute(s)")
        self.hour = Counter("hour(s)")

    def Tick(self):
        self.second.Increment()
        if self.second._count == 60:
            self.second.Reset()
            self.minute.Increment()
            if self.minute._count == 60:
                self.minute.Reset()
                self.hour.Increment()
                if self.hour._count == 24:
                    self.hour.Reset()

    def Reset(self):
        self.second.Reset()
        self.minute.Reset()
        self.hour.Reset()

    def CurrentTime(self):
        print(self.hour._count,self.hour._name,self.minute._count ,self.minute._name,self.second._count,self.second._name)

HaiAnhclock = Clock()
i = 0
while i < 86400:
    HaiAnhclock.Tick()
    HaiAnhclock.CurrentTime()
    i += 1