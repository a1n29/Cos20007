using SwinAdventure;
using System.Collections;
using System.Xml.Linq;

namespace Tester
{
    public class Tests
    {
        Location hanoi;
        Location saigon;
        Paths path;
        [Test]
        public void LookCmd()
        {
            Player player = new Player("Anh","Pro csgo player");
            Item ak47 = new Item(new string[] { "ak47" }, "AK47", "High damage, moderate firerate, high accuracy");
            player.Inventory.Put(ak47);
            Command usercommand = new CommandProcessor();
            usercommand.Execute(player, new string[] { "look at me" });
            string required = "\nAK47 (ak47)";
            string output = player.Inventory.ItemList.ToString() ;
            Assert.AreEqual(required, output);
        }
        [Test]
        public void MoveCmd()
        {
            Player player = new Player("Anh", "Pro csgo player");
            Location hanoi = new Location("Hanoi", "Capital");
            Location saigon = new Location("Saigon", "Biggest city in the south");
            Paths hanoisaigon = new Paths(new string[] { "south" }, "NorthtoSouth", "From Hanoi to Saigon", hanoi, saigon);
            hanoi.AddPath(hanoisaigon);
            player.Location = hanoi;
            Command usercommand = new CommandProcessor();
            string required = "You have successfully moved to another location !";
            string output = usercommand.Execute(player, new string[] { "move","south" });
            Assert.AreEqual(required, output);
        }
        [Test]
        public void InvalidCmd()
        {
            Player player = new Player("Anh", "Pro csgo player");
            Location hanoi = new Location("Hanoi", "Capital");
            Location saigon = new Location("Saigon", "Biggest city in the south");
            Paths hanoisaigon = new Paths(new string[] { "south" }, "NorthtoSouth", "From Hanoi to Saigon", hanoi, saigon);
            hanoi.AddPath(hanoisaigon);
            player.Location = hanoi;
            Command usercommand = new CommandProcessor();
            string required = "This is invalid !!!";
            string output = usercommand.Execute(player, new string[] { "move", "swinburne" });
            Assert.AreEqual(required, output);
        }
    }
}