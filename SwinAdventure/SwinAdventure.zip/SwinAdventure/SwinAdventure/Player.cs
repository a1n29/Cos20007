﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwinAdventure
{
        public class Player : GameObject, IHaveInventory
        {
            Location _location;
            Inventory _inventory;
            public Player(string name, string desc) : base(new string[] { "me", "inventory" }, name, desc)
            {
                _inventory = new Inventory();
            }
            public GameObject Locate(string id)
            {
                if (AreYou(id))
                {
                    return this;
                }
                GameObject gameobject = _inventory.Fetch(id);
                if (gameobject != null)
                {
                    return gameobject;
                }
                if (_location != null)
                {
                    gameobject = _location.Locate(id);
                    return gameobject;
                }
                else
                {
                    return null;
                }
            }
        public void Move(Paths path)
        {
            if (path.Destination != null)
            {
                _location = path.Destination;
            }
        }
            public override string FullDescription
            {
                get
                {
                    return $"{Name}, you are carrying: \n" + _inventory.ItemList;
                }
            }

        public Inventory Inventory => _inventory;
        public Location Location
        {
            get { return _location; }
           set { _location = value; }
        }
    }
    }
