﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwinAdventure
{
    public class MoveCommand : Command
    {
        public MoveCommand() : base(new string[] { "move" }) { }
        public override string Execute(Player p, string[] text)
        {
            string pathcmd;
            string invalid = "This is invalid !!!";
            if (text.Length == 1)
            {
                return "Please enter your destination in the correct format please !";
            }
            else if (text.Length == 2)
            {
                pathcmd = text[1].ToLower();
            }
            else if (text.Length == 3)
            {
                pathcmd = text[2].ToLower();
            }
            else
            {
                return invalid;
            }
            GameObject path = p.Location.Locate(pathcmd);
            if (path != null)
            {
                p.Move((Paths)path);
                return "You have successfully moved to another location !";
            }
            else
            {
                return invalid;
            }
        }
    }
}
