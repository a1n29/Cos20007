﻿using SwinAdventure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
namespace Tester
{
    [TestFixture]
    internal class Tester
    {
        [Test]
        public void TestAreYou()
        {
            IdentifiableObject testobject = new IdentifiableObject(new string[] { "fred","bob"});

            Assert.IsTrue(testobject.AreYou("fred"));
            Assert.IsTrue(testobject.AreYou("bob"));
        }
        [Test]
        public void TestNotAreYou()
        {
            IdentifiableObject testobject = new IdentifiableObject(new string[] { "fred", "bob" });

            Assert.IsFalse(testobject.AreYou("wilma"));
            Assert.IsFalse(testobject.AreYou("boby"));
        }
        [Test]
        public void TestCaseSensitive()
        {
            IdentifiableObject testobject = new IdentifiableObject(new string[] { "fred", "bob" });

            Assert.IsTrue(testobject.AreYou("FRED"));
            Assert.IsTrue(testobject.AreYou("bOB"));
        }
        [Test]
        public void TestFirstID()
        {
            IdentifiableObject testobject = new IdentifiableObject(new string[] { "fred", "bob" });
            
            Assert.IsTrue(testobject.FirstId == "fred");
        }
        [Test]
        public void TestNoID() 
        {
            IdentifiableObject testobject = new IdentifiableObject(new string[] { "fred", "bob" });
            Assert.IsTrue(testobject.FirstId == "");
        }
        [Test]
        public void TestAddID() 
        {
            IdentifiableObject testobject = new IdentifiableObject(new string[] { "fred", "bob" });
            testobject.AddIdentifier("wilma");
            Assert.IsTrue(testobject.AreYou("fred"));
            Assert.IsTrue(testobject.AreYou("bob"));
            Assert.IsTrue(testobject.AreYou("wilma"));
        }
    }
}
