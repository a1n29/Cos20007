using SplashKitSDK;
namespace ShapeDrawer
{
    public class Program
    {
        public static void Main()
        {
            Shape myshape = new Shape(0,0,100,100);
            Window window = new Window("Shape Drawer", 800,
            600);
            do
            {
                SplashKit.ProcessEvents();
                SplashKit.ClearScreen();
                myshape.draw();
                if (SplashKit.MouseClicked(MouseButton.LeftButton))
                {
                    myshape.X = SplashKit.MouseX() ;
                    myshape.Y = SplashKit.MouseY() ;
                    myshape.draw();
                }
                if (SplashKit.KeyTyped(KeyCode.SpaceKey) && myshape.IsAt(SplashKit.MousePosition()))
                {
                    myshape.Color = SplashKit.RandomRGBColor(255);
                    myshape.draw();
                }
                myshape.draw();
                SplashKit.RefreshScreen();
            } while (!window.CloseRequested);
        }
    }
    public class Shape
    {
        private Color _color = Color.Green;
        private float _x;
        private float _y;
        private int _width;
        private int _height;
        public Color Color
        {
            get
            {
                return _color;
            }
            set
            {
                _color = value;
            }
        }
        public float X
        {
            get
            {
                return _x;
            }
            set
            {
                _x = value;
            }
        }
        public float Y
        {
            get
            {
                return _y;
            }
            set
            {
                _y = value;
            }
        }
        public int Width
        {
            get
            {
                return _width;
            }
            set
            {
                _width = value;
            }
        }
        public int Height
        {
            get
            {
                return _height;
            }
            set
            {
                _height = value;
            }
        }
        public Shape(int x, int y, int width, int height)
        {
            _x = x;
            _y = y;
            _width = width;
            _height = height;
        }
        public void draw()
        {
            SplashKit.FillRectangle(_color, _x , _y , _width, _height);;
        }
        public bool IsAt(Point2D coor)
        {
            return (coor.X >= _x && coor.X <= _x + _width) && (coor.Y >= _y && coor.Y <= _y + _height);
        }
    }
}