﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwinAdventure
{
    public class CommandProcessor : Command
    {
        string invalidcmd = "This command is invalid !!!";
        List<Command> commands;
        public CommandProcessor():base(new string[] {"command"})
        {
            commands = new List<Command>();
            commands.Add(new LookCommand());
            commands.Add(new MoveCommand());
        }
        public override string Execute(Player p, string[] text)
        {
            foreach (Command c  in commands)
            {
                if (c.AreYou(text[0].ToLower()))
                {
                    return c.Execute(p, text);
                }
            }
            return invalidcmd;
        }
    }
}
