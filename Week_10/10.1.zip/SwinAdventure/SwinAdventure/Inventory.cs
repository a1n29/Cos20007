﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwinAdventure
{
    public class Inventory
    {
        List<Item> _Item;
        public Inventory()
        {
            _Item = new List<Item>();
        }
        public bool HasItem(string id)
        {
            foreach (Item i in _Item)
            {
                if (i.AreYou(id))
                {
                    return true;
                }
            }
            return false;
        }
        public void Put(Item Item)
        {
            _Item.Add(Item);
        }
        public Item Fetch(string id)
        {
            foreach (Item i in _Item)
            {
                if (i.AreYou(id))
                {
                    return i;
                }
            }
            return null;
        }
        public Item Take(string id)
        {
            Item TakenItem = Fetch(id);
            if (TakenItem != null)
            {
                _Item.Remove(TakenItem);
                return TakenItem;
            }
            return null;
        }
        public string ItemList
        {
            get
            {
                string Itemlist = new string("");
                foreach (Item i in _Item)
                {
                    Itemlist = Itemlist + i.ShortDescription;
                }
                return Itemlist;
            }
        }
        public int ItemCount{ get { return _Item.Count; } }
    }
}
