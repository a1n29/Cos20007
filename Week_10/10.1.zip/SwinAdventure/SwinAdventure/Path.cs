﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwinAdventure
{
    public class Paths : GameObject
    {
        Location _destination;
        Location _currentloc;
        bool _valid;
        public Paths (string[] ids, string name, string desc, Location currentloc, Location destination) : base(ids, name, desc)
        {
            {
                AddIdentifier("path");
                _valid = false;
                _currentloc = currentloc;
                _destination = destination;
                foreach (string s in name.Split(' '))
                {
                    AddIdentifier(s);
                }
            }
        }
        public bool Valid
        {
            get { return _valid; }
            set { _valid = value; }
        }
        public Location Destination
        {
            get { return _destination; }
            set { _destination = value; }
        }
        public override string ShortDescription
        {
            get { return Name; }
        }
    }
}
