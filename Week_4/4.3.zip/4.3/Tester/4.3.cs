using SwinAdventure;

namespace Tester
{
    public class Tests
    {
        Bags bag1,bag2;

        Item axe = new Item(new string[] { "axe" }, "an axe", "This is a axe");
        Item gun = new Item(new string[] { "gun" }, "a gun", "This is a gun");
        Item grenade = new Item(new string[] { "grenade" }, "a grenade", "This is a grenade");
        Item bomb = new Item(new string[] { "bomb" }, "a bomb", "This is a bomb");


        [SetUp]
        public void Setup()
        {
            bag1 = new Bags(new string[] { "bag1" }, "a bag 1", "This is a bag 1");
            bag2 = new Bags(new string[] { "bag2" }, "a bag 2", "This is a bag 2");
            bag1.Inventory.Put(axe); bag1.Inventory.Put(gun);
            bag2.Inventory.Put(grenade); bag2.Inventory.Put(bomb);
        }

        [Test]
        public void TestBagLocatesItems()
        {
            Assert.IsTrue(bag1.Inventory.HasItem("gun")); 
            Assert.IsTrue(bag1.Inventory.HasItem("axe"));

            Assert.IsTrue(bag1.Locate(gun.FirstId) == gun);
            Assert.IsTrue(bag1.Locate(axe.FirstId) == axe);

        }
        [Test]
        public void TestBagLocatesItself()
        {
            Assert.IsTrue(bag1.Locate(bag1.FirstId) == bag1);
            Assert.IsTrue(bag1.Locate("bag1") == bag1);
        }

        [Test]
        public void TestBagLocatesNothing()
        {
            Assert.IsTrue(bag1.Locate(grenade.FirstId) == null);
        }

        [Test]
        public void TestBagFullDescription()
        {
            Assert.That(bag1.FullDescription, Is.EqualTo("a bag 1 has these items:\nan axe (axe)a gun (gun)"));
        }

        [Test]
        public void TestBagInBag()
        {
            bag1.Inventory.Put(bag2);
            Assert.IsTrue(bag1.Locate(bag2.FirstId) == bag2);
            Assert.IsTrue(bag1.Locate(gun.FirstId) == gun);
            Assert.IsFalse(bag1.Locate(grenade.FirstId) == grenade);

            Assert.That(bag1.FullDescription, Is.EqualTo("a bag 1 has these items:\nan axe (axe)a gun (gun)a bag 2 (bag2)"));
            Assert.That(bag2.FullDescription,Is.EqualTo("a bag 2 has these items:\na grenade (grenade)a bomb (bomb)")); 


        }
    }
}