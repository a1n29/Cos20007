﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwinAdventure
{
    public class Inventory
    {
        List<Item> _Item = new List<Item>();
        public Inventory()
        {
        }
        public bool HasItem(string id)
        {
            foreach (Item i in _Item)
            {
                if (i.AreYou(id))
                {
                    return true;
                }
            }
            return false;
        }
        public void Put(Item Item)
        {
            _Item.Add(Item);
        }
        public  Item Fetch(string id)
        {
            foreach (Item i in _Item)
            {
                if (i.AreYou(id))
                {
                    return i;
                }
            }
            return null;
        }
        public Item Take(string id)
        {
        Item takeItem = this.Fetch(id);
        _Item.Remove(takeItem);
        return takeItem;
        }
        public string ItemList
        {
            get
            {
                string Itemlist = new string("");
                foreach (Item i in _Item)
                {
                    Itemlist = Itemlist + i.ShortDescription;
                }
                return Itemlist;
            }
        }
    }
}
