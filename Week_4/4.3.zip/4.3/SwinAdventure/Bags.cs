﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwinAdventure
{
    public class Bags : Item
    {
        Inventory _inventory = new Inventory();
        public Bags(string[] ids, string name, string desc) :base(ids, name, desc)
        {
        
        }
        public GameObject Locate(string id) 
        {
            if (AreYou(id))
            {
                return this;
            }
            if(_inventory.HasItem(id))
            {
                return _inventory.Fetch(id);
            }
            return null;
        }
        public override string FullDescription
        {
            get
            {
                return $"{this.Name} has these items:\n" + _inventory.ItemList;
            }
        }
        public Inventory Inventory { get { return _inventory; } }
    }
}
